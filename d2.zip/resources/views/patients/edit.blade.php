@extends('layouts.app')

@section('content')
    <h2>Edit patient</h2>

    @if($errors->any())
        <ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
    @endif

    <form action="{{ route('patients.update', $patient->id) }}" method="POST">
        @csrf @method('PUT')
        Name: <input type="text" name="name" value="{{ $patient->name }}"><br>
        Email: <input type="email" name="email" value="{{ $patient->email }}"><br>
        Mobile: <input type="text" name="mobile" value="{{ $patient->mobile }}"><br>
         address: <input type="text" name="address" value="{{ $patient->address }}"><br>
        <button type="submit">Update</button>
    </form>
@endsection
