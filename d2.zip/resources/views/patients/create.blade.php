@extends('layouts.app')

@section('content')
    <h2>Add patient</h2>

    @if($errors->any())
        <ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
    @endif

    <form action="{{ route('patients.store') }}" method="POST">
        @csrf
        Name: <input type="text" name="name" value="{{ old('name') }}"><br>
        Email: <input type="email" name="email" value="{{ old('email') }}"><br>
        Mobile: <input type="text" name="mobile" value="{{ old('mobile') }}"><br>
        address: <input type="text" name="address" value="{{ old('address') }}"><br>
        <button type="submit">Save</button>
    </form>
@endsection
