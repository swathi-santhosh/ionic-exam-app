
@extends('layouts.app')

@section('content')
<form action="{{ route('appointments.store') }}" method="POST">
    @csrf

    <label for="doctor_id">Doctor:</label>
    <select name="doctor_id" required>
        @foreach($doctors as $doctor)
            <option value="{{ $doctor->id }}">{{ $doctor->name }}</option>
        @endforeach
    </select>

    <label for="patient_id">Patient:</label>
    <select name="patient_id" required>
        @foreach($patients as $patient)
            <option value="{{ $patient->id }}">{{ $patient->name }}</option>
        @endforeach
    </select>

    <label for="appointment_date">Date:</label>
    <input type="date" name="appointment_date" required>

    <button type="submit">Create Appointment</button>
</form>
@endsection