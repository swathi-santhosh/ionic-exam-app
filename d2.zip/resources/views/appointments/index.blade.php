
@extends('layouts.app')

@section('content')
<h2>Appointments List</h2>

    <a href="{{ route('appointments.create') }}">Add appointments</a>

    @if(session('success'))
        <p>{{ session('success') }}</p>
    @endif
<table border="1">
    <tr>
        <th>Doctor</th>
        <th>Patient</th>
        <th>Date</th>
    </tr>
    @foreach($appointments as $appointment)
        <tr>
            <td>{{ $appointment->doctor->name }}</td>
            <td>{{ $appointment->patient->name }}</td>
            <td>{{ $appointment->appointment_date }}</td>
        </tr>
    @endforeach
</table>
@endsection