@extends('layouts.app')

@section('content')
    <h2>doctors List</h2>
    <a href="{{ route('doctors.create') }}">Add doctor</a>

    @if(session('success'))
        <p>{{ session('success') }}</p>
    @endif

    <table border="1">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Actions</th>
        </tr>
        @foreach($doctors as $doctor)
            <tr>
                <td>{{ $doctor->name }}</td>
                <td>{{ $doctor->email }}</td>
                <td>{{ $doctor->mobile }}</td>
                <td>
                    <a href="{{ route('doctors.edit', $doctor->id) }}">Edit</a>
                    <form action="{{ route('doctors.destroy', $doctor->id) }}" method="POST" style="display:inline;">
                        @csrf @method('DELETE')
                        <button type="submit" onclick="return confirm('Delete this doctor?')">Delete</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
@endsection
