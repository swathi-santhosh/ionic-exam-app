@extends('layouts.app')

@section('content')
    <h2>Add doctor</h2>

    @if($errors->any())
        <ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
    @endif

    <form action="{{ route('doctors.store') }}" method="POST">
        @csrf
        Name: <input type="text" name="name"><br>
        Email: <input type="email" name="email"><br>
        Mobile: <input type="text" name="mobile"><br>
        address: <input type="text" name="address"><br>
        <button type="submit">Save</button>
    </form>
@endsection
