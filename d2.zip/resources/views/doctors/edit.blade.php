@extends('layouts.app')

@section('content')
    <h2>Edit doctor</h2>

    @if($errors->any())
        <ul>@foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul>
    @endif

    <form action="{{ route('doctors.update', $doctor->id) }}" method="POST">
        @csrf @method('PUT')
        Name: <input type="text" name="name" value="{{ $doctor->name }}"><br>
        Email: <input type="email" name="email" value="{{ $doctor->email }}"><br>
        Mobile: <input type="text" name="mobile" value="{{ $doctor->mobile }}"><br>
         address: <input type="text" name="address" value="{{ $doctor->address }}"><br>
        <button type="submit">Update</button>
    </form>
@endsection
