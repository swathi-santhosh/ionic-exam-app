<?php

namespace App\Http\Controllers;

use App\Models\Doctor;
use App\Models\User;
use Illuminate\Http\Request;

class DoctorController extends Controller
{
    public function index()
    {
        //$sessionId = session()->getId();
        // $doctors = Doctor::all();
        $doctors = User::where('role', 'doctor')->get();
        return view('doctors.index', compact('doctors'));
    }

    public function create()
    {
        return view('doctors.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:doctors',
            'mobile' => 'required|unique:doctors',
            'address' => 'required',
        ]);

        //Doctor::create($request->all());
         User::create([
        'name' => $request->name,
        'email' => $request->email,
        'mobile' => $request->mobile,
        'address' => $request->address,
        'role' => 'doctor',
        'password' => bcrypt($request->email), // hash password manually if not using model casting
        ]);

        return redirect()->route('doctors.index')->with('success', 'Added successfully.');
    }

    public function edit($id)
    {
        //$doctor = Doctor::findOrFail($id);
        $doctor = User::where('role', 'doctor')->findOrFail($id);
        return view('doctors.edit', compact('doctor'));
    }

    public function update(Request $request, $id)
    {
        //$doctor = Doctor::findOrFail($id);
        $doctor = User::where('role', 'doctor')->findOrFail($id);
        $request->validate([
            'name' => 'required',
            'email' => "required|email|unique:doctors,email,$id",
            'mobile' => "required|unique:doctors,mobile,$id",
            'address' => 'required',
        ]);

        $data = $request->only('name', 'email', 'mobile', 'address');

        // Update password as hashed email
        $data['password'] = bcrypt($request->email);

        $doctor->update($data);

       // $doctor->update($request->all());
        return redirect()->route('doctors.index')->with('success', 'updated successfully.');
    }

    public function destroy($id)
    {
        //Doctor::findOrFail($id)->delete();
        $doctor = User::where('role', 'doctor')->findOrFail($id);
        $doctor->delete();
        return redirect()->route('doctors.index')->with('success', 'deleted successfully.');
    }
}
