<?php

namespace App\Http\Controllers;

use App\Models\Appointment;
use App\Models\Doctor;
use App\Models\Patient;
use Illuminate\Http\Request;

class AppointmentController extends Controller
{



public function create()
{
    $doctors = Doctor::all();
    $patients = Patient::all();
    return view('appointments.create', compact('doctors', 'patients'));
}

public function store(Request $request)
{
    $request->validate([
        'doctor_id' => 'required|exists:doctors,id',
        'patient_id' => 'required|exists:patients,id',
        'appointment_date' => 'required|date',
    ]);

    Appointment::create($request->all());

    return redirect()->route('appointments.index')->with('success', 'Appointment created.');
}

public function index()
{
    // You can use either Eloquent or a JOIN here

    // Eloquent with relationships:
    $appointments = Appointment::with(['doctor', 'patient'])->get();
    // $appointments = Appointment::with(['doctor', 'patient'])
    // ->where('status', 1)
    // ->get();

    return view('appointments.index', compact('appointments'));


    // $appointments = DB::table('appointments')
    //     ->join('doctors', 'appointments.doctor_id', '=', 'doctors.id')
    //     ->join('patients', 'appointments.patient_id', '=', 'patients.id')
    //     ->select('appointments.*', 'doctors.name as doctor_name', 'patients.name as patient_name')
    //     ->get();

    // return view('appointments.index', compact('appointments'));
//     @foreach($appointments as $appointment)
//     <tr>
//         <td>{{ $appointment->doctor_name }}</td>
//         <td>{{ $appointment->patient_name }}</td>
//         <td>{{ $appointment->appointment_date }}</td>
//     </tr>
// @endforeach
}

}
