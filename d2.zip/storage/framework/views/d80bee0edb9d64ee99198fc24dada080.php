

<?php $__env->startSection('content'); ?>
    <h2>Add patient</h2>

    <?php if($errors->any()): ?>
        <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
    <?php endif; ?>

    <form action="<?php echo e(route('patients.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        Name: <input type="text" name="name" value="<?php echo e(old('name')); ?>"><br>
        Email: <input type="email" name="email" value="<?php echo e(old('email')); ?>"><br>
        Mobile: <input type="text" name="mobile" value="<?php echo e(old('mobile')); ?>"><br>
        address: <input type="text" name="address" value="<?php echo e(old('address')); ?>"><br>
        <button type="submit">Save</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\dental-clinic\resources\views/patients/create.blade.php ENDPATH**/ ?>