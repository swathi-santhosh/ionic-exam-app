

<?php $__env->startSection('content'); ?>
    <h2>Add doctor</h2>

    <?php if($errors->any()): ?>
        <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
    <?php endif; ?>

    <form action="<?php echo e(route('doctors.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        Name: <input type="text" name="name"><br>
        Email: <input type="email" name="email"><br>
        Mobile: <input type="text" name="mobile"><br>
        address: <input type="text" name="address"><br>
        <button type="submit">Save</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\dental-clinic\resources\views/doctors/create.blade.php ENDPATH**/ ?>