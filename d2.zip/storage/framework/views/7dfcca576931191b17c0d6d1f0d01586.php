

<?php $__env->startSection('content'); ?>
    <h2>patients List</h2>
    <a href="<?php echo e(route('patients.create')); ?>">Add patient</a>

    <?php if(session('success')): ?>
        <p><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <table border="1">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Actions</th>
        </tr>
        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($patient->name); ?></td>
                <td><?php echo e($patient->email); ?></td>
                <td><?php echo e($patient->mobile); ?></td>
                <td>
                    <a href="<?php echo e(route('patients.edit', $patient->id)); ?>">Edit</a>
                    <form action="<?php echo e(route('patients.destroy', $patient->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" onclick="return confirm('Delete this patient?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\dental-clinic\resources\views/patients/index.blade.php ENDPATH**/ ?>