

<?php $__env->startSection('content'); ?>
    <h2>doctors List</h2>
    <a href="<?php echo e(route('doctors.create')); ?>">Add doctor</a>

    <?php if(session('success')): ?>
        <p><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <table border="1">
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th>Actions</th>
        </tr>
        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($doctor->name); ?></td>
                <td><?php echo e($doctor->email); ?></td>
                <td><?php echo e($doctor->mobile); ?></td>
                <td>
                    <a href="<?php echo e(route('doctors.edit', $doctor->id)); ?>">Edit</a>
                    <form action="<?php echo e(route('doctors.destroy', $doctor->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" onclick="return confirm('Delete this doctor?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\dental-clinic\resources\views/doctors/index.blade.php ENDPATH**/ ?>