


<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('appointments.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <label for="doctor_id">Doctor:</label>
    <select name="doctor_id" required>
        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($doctor->id); ?>"><?php echo e($doctor->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label for="patient_id">Patient:</label>
    <select name="patient_id" required>
        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($patient->id); ?>"><?php echo e($patient->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label for="appointment_date">Date:</label>
    <input type="date" name="appointment_date" required>

    <button type="submit">Create Appointment</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\dental-clinic\resources\views/appointments/create.blade.php ENDPATH**/ ?>