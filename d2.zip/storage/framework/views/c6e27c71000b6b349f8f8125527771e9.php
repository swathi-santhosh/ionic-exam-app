


<?php $__env->startSection('content'); ?>
<h2>Appointments List</h2>

    <a href="<?php echo e(route('appointments.create')); ?>">Add appointments</a>

    <?php if(session('success')): ?>
        <p><?php echo e(session('success')); ?></p>
    <?php endif; ?>
<table border="1">
    <tr>
        <th>Doctor</th>
        <th>Patient</th>
        <th>Date</th>
    </tr>
    <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($appointment->doctor->name); ?></td>
            <td><?php echo e($appointment->patient->name); ?></td>
            <td><?php echo e($appointment->appointment_date); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\dental-clinic\resources\views/appointments/index.blade.php ENDPATH**/ ?>